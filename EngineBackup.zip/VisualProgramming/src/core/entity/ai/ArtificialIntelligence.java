package core.entity.ai;


public interface ArtificialIntelligence {
}
