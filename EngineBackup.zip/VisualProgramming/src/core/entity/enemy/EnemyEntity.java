package core.entity.enemy;

import core.entity.AbstractEntity;
import core.level.AbstractLevel;

public abstract class EnemyEntity extends AbstractEntity {

    public EnemyEntity(final AbstractLevel level) {
        super(level);
    }

}
