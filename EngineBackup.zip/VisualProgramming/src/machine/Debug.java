package machine;

public class Debug {
    public static final boolean ON = true;
}
