package core.math;

import static org.junit.Assert.*;

import org.junit.Test;

public class Vec2DTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
